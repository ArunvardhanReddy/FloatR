import React, { Component } from 'react';
import './emiform.css';


class EMIForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: '',
            showValues: false
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    handleChange(event) {
        this.setState({ value: event.target.value });
    }
    handleSubmit(event) {
        this.setState({ showValues: true });
    }
    val() {
        var message = document.getElementById("message").value;
        display_message.innerHTML = message;
    }
    render() {
        return (
            <div className="emi-form">
                <h1 className='emi-name'>Loan EMI Calculator</h1>
                <div className="form">
                    <form className="form-horizontal">
                        <div className="form-group">
                            <label className="control-label col-md-3" htmlFor="name">Loan Amount (&#8377;)</label>
                            <input type="text" className="form-control" onChange={this.handleChange} ref="amount" name="amount" defaultValue="1500000" />
                            <label className="control-label col-md-3" htmlFor="name">INR</label>
                        </div>
                        <div className="form-group">
                            <label className="control-label col-md-3" htmlFor="tenure">Loan Tenure</label>
                            <input type="text" className="form-control" onChange={this.handleChange} ref="tenure" name="tenure" defaultValue="240" />
                            <label className="control-label col-md-3" htmlFor="name">MONTHS</label>
                        </div>
                        <div className="form-group">
                            <label className="control-label col-md-3" htmlFor="interest">Interest Rate (%)</label>
                            <input type="text" className="form-control" onChange={this.handleChange} ref="interest" name="interest" defaultValue="12.75" />
                            <label className="control-label col-md-3" htmlFor="name">%</label>
                        </div>
                        <div className="form-group">
                            <input type="submit" value="Calculate" />
                        </div>
                    </form>
                </div>
                <div className='row'>
                    <div className="col-md-6 col-sm-6">
                        <div className="sect">
                            <h4>Monthly Payment</h4>
                            <h3>&#8377; {(501234.00)}</h3>
                        </div>                      <div className="sect">
                            <h4>Total Interest Payable</h4>
                            <h3>&#8377; {12}</h3>                        </div>
                        <div className="sect">
                            <h4>Total Payment (Principal + Interest)</h4>
                            <h3>&#8377; {(3445666)}</h3>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default EMIForm