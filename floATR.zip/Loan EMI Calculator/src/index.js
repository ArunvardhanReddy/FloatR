import React from 'react';
import ReactDOM from 'react-dom';
import EMIForm from './components/EMIForm';

ReactDOM.render(
  <React.StrictMode>
    <EMIForm />
  </React.StrictMode>,
  document.getElementById('root')
);

